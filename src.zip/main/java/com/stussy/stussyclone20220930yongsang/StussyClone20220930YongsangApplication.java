package com.stussy.stussyclone20220930yongsang;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StussyClone20220930YongsangApplication {

	public static void main(String[] args) {
		SpringApplication.run(StussyClone20220930YongsangApplication.class, args);
	}

}
